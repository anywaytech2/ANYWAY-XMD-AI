<h1 align="center">✨ 𝐁𝐄𝐋𝐓𝐀𝐇 𝐌𝐃 ✨</h1>

<p align="center">
  <a href="https://github.com/Beltah254/X-BOT">
    <img alt="BELTAH-MD" width="700" height="300" src="https://telegra.ph/file/dcce2ddee6cc7597c859a.jpg">
  </a>
</p>

<p align="center">
  <a href="https://github.com/Beltah254BELTAH-MD-BOT">
    <img src="https://img.shields.io/badge/BELTAH-MD-black?style=for-the-badge&logo=github" title="Author">
  </a>
  <a href="https://github.com/Beltahtech?tab=followers">
    <img src="https://img.shields.io/github/followers/Beltahtech?label=Followers&style=social" title="Followers">
  </a>
  <a href="https://github.com/Beltah254/X-BOT/stargazers/">
    <img src="https://img.shields.io/github/stars/Beltah254/X-BOT?&style=social" title="Stars">
  </a>
  <a href="https://github.com/Beltah254/X-BOT/network/members">
    <img src="https://img.shields.io/github/forks/Beltah254/X-BOT?style=social" title="Forks">
  </a>
  <a href="https://github.com/BELTAH-MD-BOT/watchers">
    <img src="https://img.shields.io/github/watchers/Huaweike/AUTOMATIC-BOT?label=Watching&style=social" title="Watching">
  </a>
</p>

<p align="center">
  <a href="https://youtu.be/Beltahtech">
    <img src="https://img.shields.io/badge/Subscribe%20on%20YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white" alt="YouTube Subscribe">
  </a>
  <a href="https://github.com/Beltah254/BELTAH-MD-BOT/fork">
    <img src="https://img.shields.io/badge/Fork%20Repo-6C33FF?style=for-the-badge&logo=github" alt="Fork Repo">
  </a>
  <a href="https://github.com/Beltah254/BELTAH-MD-BOT/stargazers">
    <img src="https://img.shields.io/badge/Star%20Repo-FFD700?style=for-the-badge&logo=star" alt="Star Repo">
  </a>
  <a href="https://bel-tah-md-sessions.onrender.com/">
    <img src="https://img.shields.io/badge/Visit%20Website-00C853?style=for-the-badge&logo=google-chrome" alt="Visit Website">
  </a>
</p>

---

## 🚀 𝐒𝐄𝐓𝐔𝐏 𝐏𝐑𝐎𝐂𝐄𝐃𝐔𝐑𝐄

> <img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=36&pause=1000&color=F75B00FF&center=true&vCenter=true&width=600&height=40&lines=Easy+3-Step+Setup" alt="setup">

1. ⭐️ **Star this Repo** &rarr; <a href="https://github.com/Beltah254/X-BOT/stargazers"><img src="https://img.shields.io/github/stars/Beltah254/X-BOT?style=social"></a>
2. 🍴 **Fork this Repo** &rarr; <a href="https://github.com/Beltah254/X-BOT/fork"><img src="https://img.shields.io/github/forks/Beltah254/X-BOT?style=social"></a>
3. 🛡️ **Get Your Session ID:**
    - <a href="https://bel-tah-md-codes.onrender.com/pair"><img src="https://img.shields.io/badge/PAIR%20CODE%201-1BAFBA?style=for-the-badge"></a>
    - <a href="https://beltah-md-sessions.onrender.com/pair"><img src="https://img.shields.io/badge/PAIR%20CODE%202-1BAFBA?style=for-the-badge"></a>
    - <a href="https://bel-tah-md-codes.onrender.com/qr"><img src="https://img.shields.io/badge/SCAN%20QR%201-00BFFF?style=for-the-badge"></a>
    - <a href="https://beltah-md-sessions.onrender.com/qr"><img src="https://img.shields.io/badge/SCAN%20QR%202-00BFFF?style=for-the-badge"></a>
    - <a href="https://beltah-md-sessions.onrender.com/"><img src="https://img.shields.io/badge/BELTAH%20TECH%20SITE-00C853?style=for-the-badge"></a>
    - <br>💡 <b>Copy your Session ID; you will need it during deployment.</b>

---

<details>
<summary><b>🆕 𝐋𝐀𝐓𝐄𝐒𝐓 𝐔𝐏𝐃𝐀𝐓𝐄𝐒 & 𝐅𝐄𝐀𝐓𝐔𝐑𝐄𝐒</b> <img src="https://img.shields.io/badge/Click%20to%20Expand-1BAFBA?style=flat-square"></summary>

| Commands Name                 | Status |
|------------------------------ |:------:|
| • AUTO REACT MESSAGE ADDED    |   ✅   |
| • AUTO REPLY MESSAGE ADDED    |   ✅   |
| • AUTO REACT STATUS ADDED     |   ✅   |
| • AUTO READ MESSAGE ADDED     |   ✅   |
| • AUTO REJECT CALL ADDED      |   ✅   |
| • AUDIO REPLY ADDED           |   ✅   |
| • AUTO SAVE CONTACTS ADDED    |   ✅   |
| • FUN CMD HACK ADDED          |   ✅   |
| • GPT ADDED                   |   ✅   |

</details>

---

## 🌈 𝐃𝐄𝐏𝐋𝐎𝐘 𝐎𝐍 𝐇𝐄𝐑𝐎𝐊𝐔

<p align="center">
  <a href="https://x-bot-fork-cheacker.vercel.app/">
    <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy to Heroku"/>
  </a>
</p>

---

<p align="center">
  <img src='https://i.imgur.com/LyHic3i.gif' width="260"/>
  <img src='https://i.imgur.com/LyHic3i.gif' width="260"/>
</p>

---

## 🛡️ 𝐃𝐈𝐒𝐂𝐋𝐀𝐈𝐌𝐄𝐑

> Copying or modifying this script is <b>not allowed!</b> No support will be provided for modified versions.

---

## 💬 𝐇𝐄𝐋𝐏 & 𝐒𝐔𝐏𝐏𝐎𝐑𝐓

- Need help? <a href="https://wa.me/254114141192"><img src="https://img.shields.io/badge/Message%20on%20WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"></a>

---

## 🙏 𝐒𝐏𝐄𝐂𝐈𝐀𝐋 𝐓𝐇𝐀𝐍𝐊𝐒 𝐓𝐎

- <a href="https://github.com/Beltahtech">**Beltah Tech 254 🇰🇪**</a> for all code and command contributions.

<br>
<p align="center">© BELTAH XBOT ® 03/01/2025</p>
